package clubProyect.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import clubProyect.model.Partner;
import java.util.List;

public interface PartnerRepository extends JpaRepository<Partner, Long> {

    // Método personalizado: Buscar por tipo de Partner
    List<Partner> findByType(boolean type);
    
    // Método personalizado: Buscar por fecha de afiliación
    List<Partner> findByAffiliationDateBetween(Date startDate, Date endDate);
}
package clubProyect.model;
import jakarta.persistence.*;  // Importa las anotaciones de JPA

@Entity
@Table(name = "invoice_detail")  // Indica que esta clase es una entidad de base de datos
public class InvoiceDetail {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)  // Genera automáticamente el id en la base de datos
@Column(name = "id_register")  // Mapear el campo al nombre de la columna
private long idRegister;

@ManyToOne  // Relación muchos a uno con la clase Invoice
@JoinColumn(name = "id_invoice")  // Llave foránea hacia la entidad Invoice@ManyToOne  // Relación muchos a uno con la clase Invoice
@JoinColumn(name = "id_invoice")  // Llave foránea hacia la entidad Invoice
private Invoice idInvoice;

@Column(name = "item")  // Mapear el campo 'item'
private int item;

@Column(name = "description")  // Mapear el campo 'description'
private String description;

@Column(name = "value_item")  // Mapear el campo 'value_item'
private double valueItem;

public InvoiceDetail() {}

public long getIdRegister() {
    return idRegister;
}
public void setIdRegister(long idRegister) {
    this.idRegister = idRegister;
}
public Invoice getIdInvoice() {
    return idInvoice;
}
public void setIdInvoice(Invoice idInvoice) {
    this.idInvoice = idInvoice;
}
public int getItem() {
    return item;
}
public void setItem(int item) {
    this.item = item;
}
public String getDescription() {
    return description;
}
public void setDescription(String description) {
    this.description = description;
}
public double getValueItem() {
    return valueItem;
}
public void setValueItem(double valueItem) {
    this.valueItem = valueItem;
}

@Override
public String toString(){
    return     "DetailsInvoices{" +
               "id Register =" + idRegister +
               ", idInvoice =" + idInvoice +
               ", numberItem =" + item +
               ", description ='" + description + '\'' +
               ", valueItem =" + valueItem +
               '}';
}



}

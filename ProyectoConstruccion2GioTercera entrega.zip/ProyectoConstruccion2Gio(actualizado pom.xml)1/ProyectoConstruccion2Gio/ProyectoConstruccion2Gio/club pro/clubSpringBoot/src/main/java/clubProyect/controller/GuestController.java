package clubProyect.controller;

import clubProyect.controller.validator.PersonValidator;
import clubProyect.service.InvoiceService;  // Suponiendo que tienes un servicio para la gestión de facturas
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.util.Scanner;

@Controller
public class GuestController implements ControllerInterface {

    private static final String MENU = "Ingrese la opción que desea realizar: "
            + "\n 1. Crear Factura"
            + "\n 2. Cerrar sesión";

    // Inyectamos los servicios necesarios
    private final InvoiceService invoiceService;
    private final PersonValidator personValidator;

    // Constructor con inyección de dependencias de Spring
    @Autowired
    public GuestController(InvoiceService invoiceService, PersonValidator personValidator) {
        this.invoiceService = invoiceService;
        this.personValidator = personValidator;
    }

    @Override
    public void session() throws Exception {
        boolean session = true;
        while (session) {
            session = menu();
        }
    }

    // Método para mostrar el menú y procesar las opciones
    private boolean menu() {
        try {
            System.out.println(MENU);
            String option = Utils.getReader().nextLine();  // Usamos un método estático de utilidad
            return this.options(option);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return true;
        }
    }

    // Método para manejar las opciones seleccionadas en el menú
    private boolean options(String option) throws Exception {
        switch (option) {
            case "1": {
                this.createInvoice();
                return true;
            }
            case "2": {
                System.out.println("Se cierra sesión");
                return false;
            }
            default: {
                System.out.println("Ingrese un valor válido");
                return true;
            }
        }
    }

    // Método para crear una factura
    private void createInvoice() throws Exception {
        System.out.println("Ingrese el monto de la factura:");
        double amount = Utils.getReader().nextDouble();
        System.out.println("Ingrese el concepto de la factura:");
        String concept = Utils.getReader().nextLine();

        // Validación simple (puedes extenderlo)
        if (amount <= 0) {
            throw new Exception("El monto debe ser mayor que 0");
        }

        // Llamamos al servicio de facturación para crear la factura
        invoiceService.createInvoice(amount, concept);

        System.out.println("Factura creada con éxito. Monto: " + amount + ", Concepto: " + concept);
    }
}
package clubProyect.dao.repository;

import clubProyect.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonRepository extends JpaRepository<Person, Long> {

    // Método personalizado: Verifica si existe una persona por documento
    boolean existsByIdentification(long identification);

    // Método personalizado: Encuentra persona por documento
    Person findByIdentification(long identification);
}
package clubProyect.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import clubProyect.model.Guest;

public interface GuestRepository extends JpaRepository<Guest, Long> {
    // Método para encontrar un Guest por su estado
    List<Guest> findByStatusActive(boolean statusActive);
    
    // Método para encontrar todos los Guests de un Partner
    List<Guest> findByPartnerId(Partner partner);
}
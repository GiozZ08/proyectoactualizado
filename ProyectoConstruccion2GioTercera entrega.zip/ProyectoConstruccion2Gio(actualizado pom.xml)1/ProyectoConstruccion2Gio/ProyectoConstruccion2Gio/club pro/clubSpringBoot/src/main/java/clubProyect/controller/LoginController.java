package clubProyect.controller;

import clubProyect.controller.validator.UserValidator;
import clubProyect.dto.UserDto;
import clubProyect.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import java.util.HashMap;
import java.util.Map;

@Controller
@SessionAttributes("role")  // Para mantener el rol del usuario en la sesión
public class LoginController implements ControllerInterface {
    
    private final UserValidator userValidator;
    private final LoginService service;
    
    // Mapa para manejar los roles
    private Map<String, ControllerInterface> roles;
    
    // Constructor con inyección de dependencias
    @Autowired
    public LoginController(UserValidator userValidator, LoginService service) {
        this.userValidator = userValidator;
        this.service = service;
        
        // Inicializar controladores por rol
        ControllerInterface adminController = new AdminController();
        ControllerInterface guestController = new GuestController();
        ControllerInterface partnerController = new PartnerController();
        
        this.roles = new HashMap<>();
        roles.put("admin", adminController);
        roles.put("guest", guestController);
        roles.put("partner", partnerController);
    }
    
    // Método que maneja la sesión de los usuarios
    @Override
    public void session() throws Exception {
        boolean session = true;
        while (session) {
            session = menu();
        }
    }
    
    // Método para mostrar el menú de login
    @GetMapping("/login")
    public String loginMenu() {
        return "login";  // Vista de login
    }
    
    // Método para procesar el login
    @PostMapping("/login")
    public String login(@RequestParam String userName, 
                        @RequestParam String password,
                        Model model) throws Exception {
        
        // Validación de nombre de usuario y contraseña
        userValidator.validUserName(userName);
        userValidator.validPassword(password);
        
        // Crear DTO de usuario y realizar login
        UserDto userDto = new UserDto();
        userDto.setUserName(userName);
        userDto.setPassword(password);
        
        this.service.login(userDto);
        
        // Verificar rol y redirigir al controlador correspondiente
        if (roles.get(userDto.getRole()) == null) {
            throw new Exception("Rol inválido");
        }
        
        // Guardar el rol en la sesión
        model.addAttribute("role", userDto.getRole());
        
        // Redirigir según el rol (puedes cambiar la ruta si es necesario)
        roles.get(userDto.getRole()).session();
        return "redirect:/" + userDto.getRole() + "/menu"; // Redirige según el rol
    }
    
    // Método para detener la ejecución (podrías agregar un logout si es necesario)
    @GetMapping("/logout")
    public String logout() {
        return "redirect:/login";  // Redirige a la página de login
    }
    
    // Menú de opciones iniciales (puedes omitir esto en Spring)
    private boolean menu() {
        try {
            System.out.println("Ingrese la opción que desea:");
            System.out.println("1. Iniciar sesión");
            System.out.println("2. Detener la ejecución");
            String option = Utils.getReader().nextLine();
            return options(option);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return true;
        }
    }
    
    // Opciones del menú
    private boolean options(String option) throws Exception {
        switch (option) {
            case "1":
                this.login();
                return true;
            case "2":
                System.out.println("Se detiene el programa");
                return false;
            default:
                System.out.println("Ingrese un valor válido");
                return true;
        }
    }
}
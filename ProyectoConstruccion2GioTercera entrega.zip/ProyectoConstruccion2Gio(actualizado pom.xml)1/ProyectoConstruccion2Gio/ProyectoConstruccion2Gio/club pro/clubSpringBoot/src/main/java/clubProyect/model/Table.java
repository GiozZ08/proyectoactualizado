package clubProyect.model;

public @interface Table {

    String name();

}

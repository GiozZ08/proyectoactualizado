package clubProyect.dao;

import clubProyect.dao.interfaces.UserDao;
import clubProyect.dao.repository.UserRepository;
import clubProyect.dto.UserDto;
import clubProyect.helper.Helper;
import clubProyect.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImplementation implements UserDao {
   
    // Inyección de dependencias
    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDto findByUserName(UserDto userDto) throws Exception {     
        return userRepository.findByUserName(userDto.getUserName());   
    }

    @Override
    public boolean existsByUserName(UserDto userDto) throws Exception {
        return userRepository.existsByUserName(userDto.getUserName());
    }

    @Override
    public void createUser(UserDto userDto) throws Exception {
        User user = Helper.parse(userDto);
        userRepository.save(user);
    }

    @Override
    public void deleteUser(UserDto userDto) throws Exception {
        User user = Helper.parse(userDto);
        userRepository.delete(user);
    }
}
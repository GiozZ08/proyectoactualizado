package clubProyect.Service;

import clubProyect.controller.Utils;
import clubProyect.dao.interfaces.GuestDao;
import clubProyect.dao.interfaces.PartnerDao;
import clubProyect.dao.interfaces.PersonDao;
import clubProyect.dao.interfaces.UserDao;
import clubProyect.dto.GuestDto;
import clubProyect.dto.PartnerDto;
import clubProyect.dto.PersonDto;
import clubProyect.dto.UserDto;
import clubProyect.Service.interfaces.AdminService;
import clubProyect.Service.interfaces.LoginService;
import clubProyect.Service.interfaces.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Service implements LoginService, AdminService, PartnerService {

    private final UserDao userDao;
    private final PersonDao personDao;
    private final PartnerDao partnerDao;
    private final GuestDao guestDao;
    public static UserDto user;

    @Autowired
    public Service(UserDao userDao, PersonDao personDao, PartnerDao partnerDao, GuestDao guestDao) {
        this.userDao = userDao;
        this.personDao = personDao;
        this.partnerDao = partnerDao;
        this.guestDao = guestDao;
    }

    public void login(UserDto userDto) throws Exception {
        UserDto validateDto = userDao.findByUserName(userDto);
        if (validateDto == null) {
            throw new Exception("No existe usuario registrado");
        }
        if (!userDto.getPassword().equals(validateDto.getPassword())) {
            throw new Exception("Usuario o contraseña incorrecto");
        }
        userDto.setRole(validateDto.getRole());
        user = validateDto;
    }

    @Override
    public void logout() {
        user = null;
        System.out.println("Se ha cerrado sesión");
    }

    @Override
    public void createPartner(PartnerDto partnerDto) throws Exception {
        this.createUser(partnerDto.getUserId());
        partnerDto.setUserId(userDao.findByUserName(partnerDto.getUserId()));
        if (partnerDto.getIncreaseFunds() < 50000) {
            this.userDao.deleteUser(partnerDto.getUserId());
            throw new Exception("El monto inicial tiene que ser mínimo 50000");
        }
        this.partnerDao.createPartner(partnerDto);
    }

    @Override
    public void createGuest(GuestDto guestDto) throws Exception {
        this.createUser(guestDto.getUserId());
        this.guestDao.createGuest(guestDto);
    }

    private void createUser(UserDto userDto) throws Exception {
        this.createPerson(userDto.getPersonId());
        userDto.setPersonId(personDao.findByDocument(userDto.getPersonId()));
        if (this.userDao.existsByUserName(userDto)) {
            this.personDao.deletePerson(userDto.getPersonId());
            throw new Exception("Ya existe un usuario con ese username");
        }
        this.userDao.createUser(userDto);
    }

    private void createPerson(PersonDto personDto) throws Exception {
        if (this.personDao.existsByDocument(personDto)) {
            throw new Exception("Ya existe una persona con ese documento");
        }
        this.personDao.createPerson(personDto);
    }

    @Override
    public void promotiontovip(PersonDto personDto) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void disableGuest(long document) throws Exception {
        GuestDto guestDto = new GuestDto();
        guestDto.setStatusActive(false);
    }
}

















    


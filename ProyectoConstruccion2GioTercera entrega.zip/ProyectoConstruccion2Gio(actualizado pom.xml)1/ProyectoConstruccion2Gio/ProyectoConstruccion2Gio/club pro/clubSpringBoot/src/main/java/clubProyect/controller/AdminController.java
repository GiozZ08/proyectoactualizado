package clubProyect.controller;

import clubProyect.controller.validator.PartnerValidator;
import clubProyect.controller.validator.PersonValidator;
import clubProyect.controller.validator.UserValidator;
import clubProyect.dto.PartnerDto;
import clubProyect.dto.PersonDto;
import clubProyect.dto.UserDto;
import clubProyect.Service.Service;
import clubProyect.Service.interfaces.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController implements ControllerInterface {

    @Autowired
    private PersonValidator personValidator;
    
    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private PartnerValidator partnerValidator;
    
    @Autowired
    private AdminService service;

    private static final String MENU = "ingrese la opcion que desea realizar "
        + "\n 1. para crear Socio "
        + "\n 2. Historial de facturas"
        + "\n 3. promocion a VIP"
        + "\n 4. cerrar sesion";
    
    @GetMapping("/admin/menu")
    public String showMenu(Model model) {
        model.addAttribute("menu", MENU);
        return "admin/menu"; // nombre de la vista, por ejemplo admin/menu.html
    }

    @PostMapping("/admin/createPartner")
    public String createPartner(@RequestParam String name,
                                @RequestParam String document,
                                @RequestParam String phoneNumber,
                                @RequestParam String userName,
                                @RequestParam String password,
                                @RequestParam String amount) throws Exception {

        // Validación
        personValidator.validName(name);
        long documentNumber = personValidator.validDocument(document);
        long cellPhone = personValidator.validCellphone(phoneNumber);
        userValidator.validUserName(userName);
        userValidator.validPassword(password);
        double initialAmount = partnerValidator.validAmount(amount);

        // Crear DTOs
        PersonDto personDto = new PersonDto();
        personDto.setName(name);
        personDto.setIdentification(documentNumber);
        personDto.setPhoneNumber(cellPhone);

        UserDto userDto = new UserDto();
        userDto.setPersonId(personDto);
        userDto.setUserName(userName);
        userDto.setPassword(password);
        userDto.setRole("partner");

        PartnerDto partnerDto = new PartnerDto();
        partnerDto.setUserId(userDto);
        partnerDto.setType(true);
        partnerDto.setIncreaseFunds(initialAmount);
        partnerDto.setAffiliationDate(Utils.getDate());

        // Llamar al servicio
        service.createPartner(partnerDto);
        
        return "redirect:/admin/menu"; // Redirige de vuelta al menú del admin
    }
}
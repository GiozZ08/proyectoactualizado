package clubProyect.dao.interfaces;

import clubProyect.dto.GuestDto;
import clubProyect.dto.PartnerDto;
import org.springframework.stereotype.Repository;

@Repository
public interface GuestDao {
   void createGuest(GuestDto guestDto) throws Exception;
   PartnerDto findPartnerWhitUserId(PartnerDto partnerDto) throws Exception;
   void disableGuest(GuestDto guestDto) throws Exception;
   void enableGuest(GuestDto guestDto) throws Exception;
}
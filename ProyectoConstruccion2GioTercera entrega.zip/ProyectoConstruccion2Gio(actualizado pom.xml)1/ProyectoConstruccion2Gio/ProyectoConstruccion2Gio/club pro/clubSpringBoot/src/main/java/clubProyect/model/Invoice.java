package clubProyect.model;

import jarkarta.persistence.*;

import java.lang.annotation.Inherited;
import java.util.Date;


@Entity
@Table(name = "invoice")
public class Invoice {

@Id
@GeneratedValue(strategy = GenerationTYpe.IDENTITY)
@Column(name = "id_invoice")
private long idInvoice;

@ManyToOne
@JoinColumn(name = "person_id") // Relaciona con la tabla 'Person'
private Person personId;

@ManyToOne
@JoinColumn(name = "partner_id") // Relaciona con la tabla 'Partner'
private Partner partnerId;

@Column(name = "date_generation")
@Temporal(TemporalType.DATE)
private Date dateGenaration;

@Column(name = "amount_total")
private double amountTotal;

@Column(name = "status_invoice")
private boolean statusInvoice;


public Invoice() {}

public long getIdInvoice() {
    return idInvoice;
}

public void setIdInvoice(long idInvoice) {
    this.idInvoice = idInvoice;
}

public Person getPersonId() {
    return personId;
}

public void setPersonId(Person personId) {
    this.personId = personId;
}

public Partner getPartnerId() {
    return partnerId;
}

public void setPartnerId(Partner partnerId) {
    this.partnerId = partnerId;
}

public Date getDateGenaration() {
    return dateGenaration;
}

public void setDateGenaration(Date dateGenaration) {
    this.dateGenaration = dateGenaration;
}

public double getAmountTotal() {
    return amountTotal;
}

public void setAmountTotal(double amountTotal) {
    this.amountTotal = amountTotal;
}

public boolean isStatusInvoice() {
    return statusInvoice;
}

public void setStatusInvoice(boolean statusInvoice) {
    this.statusInvoice = statusInvoice;
}


}









package clubProyect.controller.validator;

import org.springframework.stereotype.Component;

@Component
public class PartnerValidator extends CommonsValidator {

    public double validAmount(String amount) throws Exception {
        return super.isValidDouble("La cantidad del socio", amount);
    }
}
package clubProyect.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "guest")
public class Guest {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "id")
private long id;
@JoinColumn(name = "userid")
@OneToOne
private User userId; // Id del usuario
@JoinColumn(name = "partnerid")
@OneToOne
private Partner partnerId; //id del socio que invita
@Column(name = "status")
private boolean statusActive;



public Guest() {}


public long getId() {
    return id;
}

public void setId(long id) {
    this.id = id;
}


public User getUserId() {
    return userId;
}

public void setUserId(User userId) {
    this.userId = userId;
}


public Partner getPartnerId() {
    return partnerId;
}

public void setPartnerId(Partner partnerId) {
    this.partnerId = partnerId;
}

public boolean isStatusActive() {
    return statusActive;
}

public void setStatusActive(boolean statusActive) {
    this.statusActive = statusActive;
}





}




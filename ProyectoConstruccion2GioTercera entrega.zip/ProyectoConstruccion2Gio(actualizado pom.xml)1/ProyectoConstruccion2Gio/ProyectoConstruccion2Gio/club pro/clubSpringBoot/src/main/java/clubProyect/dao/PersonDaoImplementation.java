package clubProyect.dao;

import clubProyect.dao.repository.PersonRepository;
import clubProyect.dao.interfaces.PersonDao;
import clubProyect.dto.PersonDto;
import clubProyect.helper.Helper;
import clubProyect.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PersonDaoImplementation implements PersonDao {

    // Inyección de dependencias
    @Autowired
    private PersonRepository personRepository;

    @Override
    public boolean existsByIdentification(PersonDto personDto) throws Exception {
        // Verificar si el documento existe
        return personRepository.existsByIdentification(personDto.getIdentification());
    }

    @Override
    public void createPerson(PersonDto personDto) throws Exception {
        // Convertir el DTO a entidad Person
        Person person = Helper.parse(personDto);
        personRepository.save(person);
    }

    @Override
    public void deletePerson(PersonDto personDto) throws Exception {
        // Convertir el DTO a entidad Person
        Person person = Helper.parse(personDto);
        personRepository.delete(person);
    }

    @Override
    public PersonDto findByIdentification(PersonDto personDto) throws Exception {
        // Buscar por documento
        Person person = personRepository.findByIdentification(personDto.getIdentification());
        return Helper.parse(person);
    }
}

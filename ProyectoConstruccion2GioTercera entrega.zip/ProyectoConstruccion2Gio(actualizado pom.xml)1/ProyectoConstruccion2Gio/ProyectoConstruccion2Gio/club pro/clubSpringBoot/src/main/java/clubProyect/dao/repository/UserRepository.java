package clubProyect.dao.repository;

import clubProyect.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    // Método personalizado: Encuentra un usuario por su nombre de usuario
    User findByUserName(String userName);

    // Método personalizado: Verifica si ya existe un usuario con el mismo nombre de usuario
    boolean existsByUserName(String userName);
}
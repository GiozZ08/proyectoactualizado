package clubProyect.controller.validator;

import org.springframework.stereotype.Component;

@Component
public abstract class CommonsValidator {

    public void isValidString(String element, String value) throws Exception {
        if (value == null || value.trim().isEmpty()) {
            throw new Exception(element + " no puede ser un valor vacío");
        }
    }

    public int isValidInteger(String element, String value) throws Exception {
        isValidString(element, value);
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new Exception(element + " debe ser un valor válido");
        }
    }

    public long isValidLong(String element, String value) throws Exception {
        isValidString(element, value);
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            throw new Exception(element + " debe ser un valor válido");
        }
    }

    public double isValidDouble(String element, String value) throws Exception {
        isValidString(element, value);
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new Exception(element + " debe ser un valor válido");
        }
    }
}
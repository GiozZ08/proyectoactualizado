package clubProyect.controller.validator;

import org.springframework.stereotype.Component;

@Component
public class UserValidator extends CommonsValidator {

    public void validUserName(String userName) throws ValidationException {
        super.isValidString("El nombre de usuario", userName);
    }

    public void validPassword(String password) throws ValidationException {
        super.isValidString("La contraseña del usuario", password);
    }

    public void validRole(String role) throws ValidationException {
        super.isValidString("El rol del usuario", role);
    }
}
    

 
        



package clubProyect.dao.interfaces;

import clubProyect.dto.PartnerDto;
import org.springframework.stereotype.Repository;

@Repository
public interface PartnerDao {
   void createPartner(PartnerDto partnerDto) throws Exception;
   void deletePartner(PartnerDto partnerDto) throws Exception;
}
package clubProyect.dao.interfaces;

import clubProyect.dto.PersonDto;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonDao {
   boolean existsByIdentification(PersonDto personDto) throws Exception;
   void createPerson(PersonDto personDto) throws Exception;
   void deletePerson(PersonDto personDto) throws Exception;
   PersonDto findByIdentification(PersonDto personDto) throws Exception;
}
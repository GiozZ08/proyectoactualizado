package clubProyect.dao;

import clubProyect.dto.PartnerDto;
import clubProyect.helper.Helper;
import clubProyect.model.Partner;
import clubProyect.dao.interfaces.PartnerDao;
import clubProyect.dao.repository.PartnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PartnerDaoImplementation implements PartnerDao {

    // Inyección de dependencias
    @Autowired
    private PartnerRepository partnerRepository;

    @Override
    public void createPartner(PartnerDto partnerDto) throws Exception {
        // Convertir el DTO a entidad Partner
        Partner partner = Helper.parse(partnerDto);
        partnerRepository.save(partner);
    }

    @Override
    public void deletePartner(PartnerDto partnerDto) throws Exception {
        // Convertir el DTO a entidad Partner
        Partner partner = Helper.parse(partnerDto);
        partnerRepository.delete(partner);  // Usar el método correcto para eliminar
    }
}
package clubProyect.model;

public @interface Entity {

}

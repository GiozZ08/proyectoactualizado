
package clubProyect.dao;

import clubProyect.dto.GuestDto;
import clubProyect.helper.Helper;
import clubProyect.model.Guest;
import clubProyect.dao.interfaces.GuestDao;
import clubProyect.dao.repository.GuestRepository;
import clubProyect.dto.PartnerDto;
import clubProyect.model.Partner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class GuestDaoImplementation implements GuestDao {

    // Inyección de dependencias
    @Autowired
    private GuestRepository guestRepository;

    @Override
    public void createGuest(GuestDto guestDto) throws Exception {
        // Convertir el DTO a entidad
        Guest guest = Helper.parse(guestDto);
        guestRepository.save(guest);
    }

    @Override
    public void disableGuest(GuestDto guestDto) throws Exception {
        // Buscar al invitado por ID o cualquier criterio relevante
    Guest guest = guestRepository.findById(guestDto.getId()).orElseThrow(() -> new Exception("Guest not found"));

    // Cambiar el estado activo a false
    guest.setStatusActive(false);

    // Guardar los cambios
    guestRepository.save(guest);
}

    
    @Override
public void enableGuest(GuestDto guestDto) throws Exception {
    // Buscar al invitado por ID o cualquier criterio relevante
    Guest guest = guestRepository.findById(guestDto.getId()).orElseThrow(() -> new Exception("Guest not found"));

    // Cambiar el estado activo a true
    guest.setStatusActive(true);

    // Guardar los cambios
    guestRepository.save(guest);
}


    @Override
    public PartnerDto findPartnerWhitUserId(PartnerDto partnerDto) throws Exception {
        
        Partner partner = guestRepository.findPartnerByUserId(partnerDto.getId());

        if (partner != null) {
            return Helper.parse(partner);
        }
        return null;
    }
}
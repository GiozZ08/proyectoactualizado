package clubProyect.dao.interfaces;

import clubProyect.dto.UserDto;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {
    UserDto findByUserName(UserDto userDto) throws Exception;
    boolean existsByUserName(UserDto userDto) throws Exception;
    void createUser(UserDto userDto) throws Exception;
    void deleteUser(UserDto userDto) throws Exception;
}
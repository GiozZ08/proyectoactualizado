package clubProyect.controller;

import clubProyect.controller.validator.PartnerValidator;
import clubProyect.controller.validator.PersonValidator;
import clubProyect.controller.validator.UserValidator;
import clubProyect.dto.GuestDto;
import clubProyect.dto.PartnerDto;
import clubProyect.dto.PersonDto;
import clubProyect.dto.UserDto;
import clubProyect.service.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PartnerController implements ControllerInterface {
    
    private final PersonValidator personValidator;
    private final UserValidator userValidator;
    private final PartnerValidator partnerValidator;
    private final PartnerService service;
    
    private static final String MENU = "Ingrese la opción que desea realizar: "
        + "\n1. Crear invitado"
        + "\n2. Incremento de fondo"
        + "\n3. Solicitud a VIP"
        + "\n4. Habilitar invitado"
        + "\n5. Deshabilitar invitado"
        + "\n6. Cerrar sesión";

    // Constructor con inyección de dependencias
    @Autowired
    public PartnerController(PersonValidator personValidator, 
                            UserValidator userValidator, 
                            PartnerValidator partnerValidator, 
                            PartnerService service) {
        this.personValidator = personValidator;
        this.userValidator = userValidator;
        this.partnerValidator = partnerValidator;
        this.service = service;
    }

    // Método para manejar la sesión de un socio
    @GetMapping("/partner/menu")
    public String menu() {
        return "partner/menu"; // Redirige a la vista del menú del socio
    }

    @PostMapping("/partner/session")
    public String session(@RequestParam String option, Model model) throws Exception {
        switch (option) {
            case "1":
                createGuest();
                break;
            case "2":
                incrementAmount();
                break;
            case "3":
                vipPromotion();
                break;
            case "4":
                activateGuest();
                break;
            case "5":
                disableGuest();
                break;
            case "6":
                return "redirect:/login"; // Redirige a la página de login
            default:
                System.out.println("Ingrese un valor válido");
                break;
        }
        return "redirect:/partner/menu";  // Vuelve al menú después de cada acción
    }

    // Método para crear un invitado
    private void createGuest() throws Exception {
        System.out.println("Ingrese el nombre del invitado:");
        String name = Utils.getReader().nextLine();
        personValidator.validName(name);
        
        System.out.println("Ingrese la cédula del invitado:");
        long document = personValidator.validDocument(Utils.getReader().nextLine());
        
        System.out.println("Ingrese el número de celular del invitado:");
        long cellPhone = personValidator.validCellphone(Utils.getReader().nextLine());
        
        System.out.println("Ingrese el nombre de usuario del invitado:");
        String userName = Utils.getReader().nextLine();
        userValidator.validUserName(userName);
        
        System.out.println("Ingrese la contraseña del invitado:");
        String password = Utils.getReader().nextLine();
        userValidator.validPassword(password);

        // Crear DTOs
        PersonDto personDto = new PersonDto();
        personDto.setName(name);
        personDto.setIdentification(document);
        personDto.setPhoneNumber(cellPhone);
        
        UserDto userDto = new UserDto();
        userDto.setPersonId(personDto);
        userDto.setUserName(userName);
        userDto.setPassword(password);
        userDto.setRole("guest"); // Definir como invitado
        
        GuestDto guestDto = new GuestDto();
        guestDto.setUserId(userDto);
        guestDto.setStatusActive(true);  // Set status to active
        
        // Llamada al servicio para crear el invitado
        this.service.createGuest(guestDto);
        System.out.println("El invitado ha sido creado exitosamente.");
    }

    // Método para incrementar fondos de un socio
    private void incrementAmount() throws Exception {
        System.out.println("Ingrese el monto que desea aumentar:");
        double amount = Utils.getReader().nextDouble();
        
        PartnerDto partnerDto = new PartnerDto();
        partnerDto.setIncreaseFunds(amount);
        
        // Llamada al servicio para incrementar fondos
        this.service.incrementFunds(partnerDto);
        System.out.println("Monto incrementado exitosamente.");
    }

    // Método para ascender a VIP
    private void vipPromotion() throws Exception {
        System.out.println("Ascender socio regular a VIP.");
        
        PartnerDto partnerDto = new PartnerDto();
        partnerDto.setType(true);  // Establecer como VIP
        
        // Llamada al servicio para la promoción
        this.service.promoteToVIP(partnerDto);
        System.out.println("El socio ha sido ascendido a VIP.");
    }

    // Método para deshabilitar un invitado
    private void disableGuest() throws Exception {
        System.out.println("Desactivar invitado.");
        System.out.println("Número de cédula del invitado:");
        long document = personValidator.validDocument(Utils.getReader().nextLine());
        
        // Llamada al servicio para deshabilitar al invitado
        this.service.disableGuest(document);
        System.out.println("El invitado ha sido desactivado.");
    }

    // Método para habilitar un invitado (puedes implementar la lógica aquí)
    private void activateGuest() throws Exception {
        System.out.println("Activar invitado.");
        System.out.println("Número de cédula del invitado:");
        long document = personValidator.validDocument(Utils.getReader().nextLine());
        
        // Llamada al servicio para habilitar al invitado
        this.service.activateGuest(document);
        System.out.println("El invitado ha sido activado.");
    }
}